﻿Buffet AllYouCanEat = new Buffet();
Ninja Goemon = new Ninja();

Goemon.Eat(AllYouCanEat);