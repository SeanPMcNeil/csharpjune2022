class Food
{
    public string Name;
    public int Calories;
    public bool IsSpicy; 
    public bool IsSweet; 

    public Food(string name, int c, bool isSp, bool isSw)
    {
        Name = name;
        Calories = c;
        IsSpicy = isSp;
        IsSweet = isSw;
    }
}
